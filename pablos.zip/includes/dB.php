<?php
$DSN='mysql:host=localhost; dbname=chestionar;charset=utf8';
$connectdb = new PDO($DSN,'root','');

?>